import { browser, ElementFinder, element, by, ExpectedConditions, ElementArrayFinder, ElementHelper } from "protractor";
import { BasePage } from "../base.po";

export class AssetAdministrationHomePage extends BasePage {

}