import { browser, by, element, ElementFinder, ExpectedConditions, ElementArrayFinder } from 'protractor';
import { BasePage } from "../base.po";


export class OrderUpdatePage extends BasePage {
  
    
    
}
