import { browser, by, element, ElementFinder, ExpectedConditions } from 'protractor';
import { BasePage } from "../base.po";

export class DispatchUpdatePage extends BasePage {
}