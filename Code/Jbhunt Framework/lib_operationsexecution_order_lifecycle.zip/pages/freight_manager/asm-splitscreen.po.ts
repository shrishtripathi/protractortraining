import { BasePage } from "../base.po";

export class ASMSplitScreenPage extends BasePage {

    constructor() {
        super();
    }

}